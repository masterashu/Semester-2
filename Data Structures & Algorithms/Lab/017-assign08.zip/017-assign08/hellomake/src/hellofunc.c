#include "hellomake.h"
#include <stdio.h>

void myPrintHelloWorld(){
    printf("Hello World!\n");
    return;
}