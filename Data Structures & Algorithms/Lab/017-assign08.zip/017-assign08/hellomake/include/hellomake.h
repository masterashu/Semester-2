// comment
void myPrintHelloWorld();