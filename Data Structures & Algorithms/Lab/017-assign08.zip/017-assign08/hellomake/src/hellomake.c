#include "hellomake.h"

int main(int argc, char const *argv[])
{
    myPrintHelloWorld();
    return 0;
}
