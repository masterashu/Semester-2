#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "Trie.h"

int GetIndex(char ch){
    #ifdef CHAR_INSENSITIVE
    return toupper(ch) - 65;
    #elif #defined  CHAR_SENSITIVE
        if(isupper(ch)){
            return (ch - 65) + 26;
        }
        else{
            return (ch - 97);
        }
    #endif
}

Trie* CreateNewNode(char ch){
    Trie* newNode = (void*)malloc(sizeof(Trie));
    #ifdef CHAR_INSENSITIVE
    newNode->data = toupper(ch);
    #elif #defined  CHAR_SENSITIVE
    newNode->data = ch;
    #endif
    newNode->childs = 0;
    newNode->isEnd = 0;
    for(int i = 0; i < CHARACTER_NO; i++){
        newNode->next[i] = NULL;
    }
}

Trie* InsertWord(Trie *myTrie, char *word){
    Trie* current = myTrie;
    while(*word != '\0'){
        int index = GetIndex(*word);
        if(current->next[index] == NULL){
            current->childs++;
            current->next[index] = CreateNewNode(*word);
        }
        if(*(word+1) == '\0'){
            current->next[index]->isEnd = 1;
        }
        current = current->next[index];
        word++;
    }
    return myTrie;
}

Trie* DeleteWord(Trie* myTrie, char* word){
    if(myTrie == NULL){         // Word Not Found
        return NULL;
    }
    else{
        char ch = *word;                            // Finding by Characters
        if(myTrie->next[GetIndex(ch)] != NULL){
            myTrie->next[GetIndex(ch)] = DeleteWord(myTrie->next[GetIndex(ch)], word + 1);
            // If Character was Found and was Deleted
            if(myTrie->next[GetIndex(ch)] == NULL){
                myTrie->childs--;
            }
        }
    }
    // Reached the end of the word and checking
    if(*word == '\0' && myTrie->data != '\0'){
        if(myTrie->isEnd){
            // Deleting End node
            if(myTrie->childs == 0){
                free(myTrie);
                return NULL;
            }
            else{
                myTrie->isEnd = 0;
            }
        }
    }
    // Deleting the Path
    else{
        if(myTrie->childs == 0 && myTrie->isEnd == 0){
            free(myTrie);
            return NULL;
        }
    }
    return myTrie;
}

int SearchWord(Trie* myTrie, char* word){
    if(myTrie == NULL){
        return 0;
    }
    else{
        if(*word == '\0'){
            return myTrie->isEnd;
        }
        else{
            return SearchWord(myTrie->next[GetIndex(*word)], word+1);
        }
    }
}

void PrintAll(Trie* myTrie, char *word, int length){
    word[length] = myTrie->data;
    for(int i = 0; i < CHARACTER_NO; i++){
        if(myTrie->next[i] != NULL){
            PrintAll(myTrie->next[i], word, length + 1);
        }
    }
    if(myTrie->isEnd){
        for(int i = 1; i <= length; i++){
            printf("%c", word[i]);
        }
        printf("\n");
    }
}



